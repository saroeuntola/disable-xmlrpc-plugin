<?php
/*
Plugin Name: Disable XML-RPC
Description: Disables and blocks XML-RPC in WordPress for enhanced security, with automatic .htaccess blocking on activation.
Version: 1.0.2
Author: Tola
*/

if (!defined('ABSPATH')) {
    exit;
}

add_filter('xmlrpc_enabled', '__return_false');
add_filter('xmlrpc_methods', '__return_empty_array');


function dxr_update_htaccess() {
    $htaccess_file = ABSPATH . '.htaccess';
    $marker = 'Disable XML-RPC';
    $rules = [
        "# BEGIN $marker",
        '<Files xmlrpc.php>',
        '    Order Allow,Deny',
        '    Deny from all',
        '</Files>',
        "# END $marker"
    ];
    $rules_string = implode("\n", $rules) . "\n";

    if (get_option('dxr_block_xmlrpc_htaccess') && is_writable($htaccess_file)) {
     
        $htaccess_content = file_get_contents($htaccess_file);
        if (strpos($htaccess_content, "# BEGIN $marker") === false) {
         
            file_put_contents($htaccess_file, $htaccess_content . "\n" . $rules_string);
        }
    } else {
        
        if (file_exists($htaccess_file) && is_writable($htaccess_file)) {
            $htaccess_content = file_get_contents($htaccess_file);
            $start = strpos($htaccess_content, "# BEGIN $marker");
            if ($start !== false) {
                $end = strpos($htaccess_content, "# END $marker") + strlen("# END $marker") + 1;
                $length = $end - $start;
                $new_content = substr_replace($htaccess_content, '', $start, $length);
                file_put_contents($htaccess_file, $new_content);
            }
        }
    }
}

add_action('admin_init', function() {
    register_setting('dxr_settings_group', 'dxr_block_xmlrpc_htaccess', [
        'sanitize_callback' => 'intval',
        'default' => 1 
    ]);
});

add_action('admin_menu', function() {
    add_submenu_page(
        'tools.php',
        'Disable XML-RPC Settings',
        'XML-RPC Settings',
        'manage_options',
        'dxr_settings',
        function() {
            if (!current_user_can('manage_options')) {
                wp_die('Unauthorized');
            }
            ?>
            <div class="wrap">
                <h1>Disable XML-RPC Settings</h1>
                <p>This plugin automatically disables XML-RPC functionality and blocks access to <code>xmlrpc.php</code> via <code>.htaccess</code> upon activation (if the <code>.htaccess</code> file is writable). You can toggle the <code>.htaccess</code> blocking below.</p>
                <form method="post" action="options.php">
                    <?php settings_fields('dxr_settings_group'); ?>
                    <table class="form-table">
                        <tr>
                            <th>Block XML-RPC via .htaccess</th>
                            <td>
                                <input type="checkbox" id="dxr_block_xmlrpc_htaccess" name="dxr_block_xmlrpc_htaccess" value="1" <?php checked(get_option('dxr_block_xmlrpc_htaccess'), 1); ?>>
                                <label for="dxr_block_xmlrpc_htaccess">Add rules to .htaccess to block access to xmlrpc.php</label>
                                <?php if (!is_writable(ABSPATH . '.htaccess')) : ?>
                                    <p style="color: red;">Warning: .htaccess file is not writable. Automatic blocking cannot be applied until file permissions are updated (e.g., <code>chmod 644 .htaccess</code>).</p>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>
                    <?php submit_button(); ?>
                </form>
            </div>
            <?php
        }
    );
});


add_action('update_option_dxr_block_xmlrpc_htaccess', 'dxr_update_htaccess');

add_action('admin_notices', function() {
    if (get_transient('dxr_activation_notice')) {
        $message = 'Disable XML-RPC plugin activated. XML-RPC is now disabled.';
        if (is_writable(ABSPATH . '.htaccess')) {
            $message .= ' Automatic .htaccess blocking has been enabled.';
        } else {
            $message .= ' Automatic .htaccess blocking could not be enabled because the .htaccess file is not writable.';
        }
        $message .= ' Configure additional settings in <a href="' . admin_url('tools.php?page=dxr_settings') . '">XML-RPC Settings</a>.';
        echo '<div class="notice notice-success is-dismissible"><p>' . $message . '</p></div>';
        delete_transient('dxr_activation_notice');
    }
});

register_activation_hook(__FILE__, function() {
    update_option('dxr_block_xmlrpc_htaccess', 1); 
    dxr_update_htaccess();
    set_transient('dxr_activation_notice', true, 30);
});


register_deactivation_hook(__FILE__, function() {
    $htaccess_file = ABSPATH . '.htaccess';
    $marker = 'Disable XML-RPC';
    if (file_exists($htaccess_file) && is_writable($htaccess_file)) {
        $htaccess_content = file_get_contents($htaccess_file);
        $start = strpos($htaccess_content, "# BEGIN $marker");
        if ($start !== false) {
            $end = strpos($htaccess_content, "# END $marker") + strlen("# END $marker") + 1;
            $length = $end - $start;
            $new_content = substr_replace($htaccess_content, '', $start, $length);
            file_put_contents($htaccess_file, $new_content);
        }
    }
});